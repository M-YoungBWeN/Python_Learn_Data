def print_data(data):
    print("读取的数据为："+data)
